angka = int(input('Masukkan angka : '))

if(angka % 2 == 0) :
    print('Angka {} tergolong bilangan GENAP!'.format(angka))
else :
    print('Angka {} tergolong bilangan GANJIL!'.format(angka))
